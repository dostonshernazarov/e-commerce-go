package main

import "product-service/connection"

func main() {
	connection.ConnGrpc()
}